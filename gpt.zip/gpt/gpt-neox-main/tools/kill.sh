pkill -9 python
