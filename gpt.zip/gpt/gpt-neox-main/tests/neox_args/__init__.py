"""
testing of implementation of command line arguments and configuration (NeoXArgs)
"""
